package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class mainactivity2 extends AppCompatActivity {
    TextView user_view,pass_view,num_view;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mainactivity2);
        user_view=findViewById(R.id.user_view);
        pass_view=findViewById(R.id.pass_view);
        num_view=findViewById(R.id.num_view);
    }

    public void show(View view) {
        SharedPreferences sharedPreferences = getSharedPreferences("Mydetails",MODE_PRIVATE);
        String name= sharedPreferences.getString("username_key","");
        String pass= sharedPreferences.getString("pass_key","");
        String number= sharedPreferences.getString("number_key","");
        user_view.setText(name);
        pass_view.setText(pass);
        num_view.setText(number);
        Toast.makeText(this, "Loaded Successfully", Toast.LENGTH_SHORT).show();
    }
}
