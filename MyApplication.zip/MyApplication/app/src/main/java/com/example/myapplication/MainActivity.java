package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText username,password,number;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        username=findViewById(R.id.username);
        password=findViewById(R.id.password);
        number=findViewById(R.id.number);
    }

    public void secondpage(View view) {
        SharedPreferences sharedPreferences = getSharedPreferences("Mydetails",MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("username_key",username.getText().toString());
        editor.putString("pass_key",password.getText().toString());
        editor.putString("number_key",number.getText().toString());
        editor.commit();
        Intent i = new Intent(this,mainactivity2.class);
        startActivity(i);
        Toast.makeText(this, "Successfully Loged In", Toast.LENGTH_SHORT).show();
    }
}
